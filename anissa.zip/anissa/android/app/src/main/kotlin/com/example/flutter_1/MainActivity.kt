package com.example.flutter_1

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
